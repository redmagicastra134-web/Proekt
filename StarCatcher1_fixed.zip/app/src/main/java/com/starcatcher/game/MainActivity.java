package com.starcatcher.game;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.view.*;
import android.content.Context;
import java.util.*;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(new GameView(this));
    }

    static class GameView extends View {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        Random r = new Random();
        ArrayList<PointF> stars = new ArrayList<>();
        float shipX, shipY, starX, starY, speed = 7;
        int score = 0;
        boolean started = false;

        GameView(Context c) {
            super(c);
            p.setTypeface(Typeface.create("sans", Typeface.BOLD));
            for(int i=0;i<90;i++) stars.add(new PointF(r.nextFloat(), r.nextFloat()));
            setFocusable(true);
        }

        protected void onSizeChanged(int w,int h,int ow,int oh) {
            shipX=w/2f; shipY=h-150;
            starX=50+r.nextFloat()*(w-100);
            starY=80;
        }

        protected void onDraw(Canvas c) {
            int w=getWidth(), h=getHeight();
            c.drawColor(Color.rgb(5,8,30));

            p.setColor(Color.WHITE);
            for(PointF s:stars) c.drawCircle(s.x*w,s.y*h,2,p);

            // moon
            p.setColor(Color.rgb(80,100,180));
            c.drawCircle(w-70,80,34,p);

            // star
            p.setColor(Color.YELLOW);
            drawStar(c, starX, starY, 22);

            // ship
            p.setColor(Color.CYAN);
            Path ship=new Path();
            ship.moveTo(shipX,shipY-45);
            ship.lineTo(shipX-30,shipY+25);
            ship.lineTo(shipX,shipY+12);
            ship.lineTo(shipX+30,shipY+25);
            ship.close();
            c.drawPath(ship,p);

            p.setTextAlign(Paint.Align.CENTER);
            p.setTextSize(42);
            c.drawText("STAR CATCHER",w/2f,65,p);
            p.setTextSize(28);
            c.drawText("Счёт: "+score,w/2f,110,p);

            if(!started){
                p.setTextSize(22);
                c.drawText("Двигай корабль пальцем",w/2f,h-70,p);
            }

            starY += speed;
            if(starY > h+30) {
                starY=-30; starX=40+r.nextFloat()*(w-80);
            }
            if(Math.abs(starX-shipX)<55 && Math.abs(starY-shipY)<65) {
                score++;
                starY=-30; starX=40+r.nextFloat()*(w-80);
                try { performHapticFeedback(1); } catch(Exception ignored) {}
            }
            invalidate();
        }

        void drawStar(Canvas c,float x,float y,float rad){
            Path q=new Path();
            for(int i=0;i<10;i++){
                double a=-Math.PI/2+i*Math.PI/5;
                float rr=(i%2==0)?rad:rad*.45f;
                float xx=x+(float)Math.cos(a)*rr, yy=y+(float)Math.sin(a)*rr;
                if(i==0) q.moveTo(xx,yy); else q.lineTo(xx,yy);
            }
            q.close(); c.drawPath(q,p);
        }

        public boolean onTouchEvent(android.view.MotionEvent e) {
            if(e.getAction()==MotionEvent.ACTION_DOWN || e.getAction()==MotionEvent.ACTION_MOVE){
                started=true;
                shipX=Math.max(45,Math.min(getWidth()-45,e.getX()));
                shipY=Math.max(150,Math.min(getHeight()-80,e.getY()));
                return true;
            }
            return true;
        }
    }
}
